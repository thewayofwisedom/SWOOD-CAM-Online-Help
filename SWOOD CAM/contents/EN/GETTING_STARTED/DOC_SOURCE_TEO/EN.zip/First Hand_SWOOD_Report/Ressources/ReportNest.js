//var nestprogfilter='';
var jsonsrc='';


function GetParametersFromUrl(){	
	if(typeof String.prototype.trim !== 'function') {
	  String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, ''); 
	  }
	}
	if(typeof String.prototype.startsWith !== 'function') {
	  String.prototype.startsWith = function (str)
	  {
		 return this.indexOf(str) == 0;
	  }
	}
	if(typeof String.prototype.endsWith !== 'function') {
	  String.prototype.endsWith = function (str)
	  {
		 return this.indexOf(str, this.length - str.length) !== -1;
	  }
	}

//	nestprogfilter='';
//	jsonsrc='';
//	var t = location.search.substring(1).split('&');
//		for (var i=0; i<t.length; i++){
//		var x = t[i].split('=');
//		if(x[0]=='progname'){
//			nestprogfilter=x[1];
//			nestprogfilter=nestprogfilter.replace('%20',' ');
//			nestprogfilter=nestprogfilter.trim();
//			if(nestprogfilter.startsWith("%22") && nestprogfilter.endsWith("%22")){
//				nestprogfilter=nestprogfilter.substring(3, nestprogfilter.length-3);
//			}
//		}
//		else if(x[0]=='jsonsrc'){
//			jsonsrc=x[1];
//			jsonsrc=jsonsrc.trim();
//			if(jsonsrc.startsWith("%22") && jsonsrc.endsWith("%22")){
//				jsonsrc=jsonsrc.substring(3, jsonsrc.length-3);
//				jsonsrc=decodeURIComponent(jsonsrc);
//			}
//		}
//	}
};

function GetProgNest(jsondata,p_Name,p_Id) {
	 if(jsondata!=null){
		for (var i = 0; i < jsondata.nest.length; i++) {
			var pnest = jsondata.nest[i];
			if (pnest.name==p_Name && pnest.id==p_Id )
			{	
				return pnest;
			}
		}
	 }
	return null;
};

function loadScript(url, callback)
{
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

    script.onreadystatechange = callback;
    script.onload = callback;

    head.appendChild(script);
};

function WriteNestingProgramsList(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteNestProg();
	}
	else{
		loadScript(jsonsrc, function() {WriteNestProgList();});
	}
};

function WriteNestProg(){
	var jsond = JSON.parse(jsondata);
	jsond.nest.pop();
	
	var srcfilename = jsonsrc.substring(jsonsrc.lastIndexOf('/')+1);
	var docsdirectory = jsonsrc.substring(0,jsonsrc.lastIndexOf('/'));


	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Cabinet list<p></div>');
	inHTML +=('<div class="separator"></div>');
	
	inHTML +=('<table class="content" style="width:100%;"');
	
//	for (var i = 0; i < jsond.nest.length; i++) {
//		var pNest=jsond.nest[i];

//		inHTML +=('<tr>');
//		inHTML +=('<td rowspan="3" align="center">');
//		inHTML +=('<a href="./ReportCabinet.html?cabname=' + pNest.name + '&jsonsrc=%22' + jsonsrc + '%22">');
//		inHTML +=('<img src="' + docsdirectory + "/IMAGE/" + pNest.img + '" width="200" height="100" border="0" />');
//		inHTML +=('</a>');
//		inHTML +=('</td>');
//		inHTML +=('<td><p>Name: ' + pNest.name + '</p></td>' );
//		inHTML +=('<td><p>Info1: ' +  + '</p></td>' );
//		inHTML +=('</tr>');
		
//		inHTML +=('<tr>');
//		inHTML +=('<td><p>Number: ' + pNest.id + '</p></td>' );
//		inHTML +=('<td><p>Info2: ' +  + '</p></td>' );
//		inHTML +=('</tr>');
	}
	inHTML +='</table>';
	inHTML +='</div>';
	out.innerHTML=inHTML;
};