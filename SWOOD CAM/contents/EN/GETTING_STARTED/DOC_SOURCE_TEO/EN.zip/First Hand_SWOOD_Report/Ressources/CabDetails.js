var cabs=new Array;
var cabfilter='';


function GetCabNameFromUrl(){	


	
	var cabn='';
	var t = location.search.substring(1).split('&');
		for (var i=0; i<t.length; i++){
		var x = t[i].split('=');
		if(x[0]=='cabname'){
			cabn=x[1];
			cabn=cabn.replace('%20',' ');
			cabn=cabn.trim();
		}
	}
	return  cabn;
}

function GetjsonsrcFromUrl(){	
	var cabn='';
	var t = location.search.substring(1).split('&');
		for (var i=0; i<t.length; i++){
		var x = t[i].split('=');
		if(x[0]=='jsonsrc'){
			cabn=x[1];
			cabn=cabn.trim();
			if(cabn.startsWith("%22") && cabn.endsWith("%22")){
				cabn=cabn.substring(3, cabn.length-3);
				cabn=decodeURIComponent(cabn);
			}
		}
	}
	return  cabn;
}


function Cabinet(u_Name,u_Num,u_Width,u_Height, u_Depth ,u_info1,u_info2,u_info3,u_img) {
	if (u_info1=='&nbsp;'){
		u_info1='';
	}
	if (u_info2=='&nbsp;'){
		u_info2='';
	}
	if (u_info3=='&nbsp;'){
		u_info3='';
	}
	
	var pCabinet = {
		Name: u_Name,
		Parts:[],
		Num: u_Num,
		Width : parseFloat(u_Width),
		Height: parseFloat(u_Height),
		Depth: parseFloat(u_Depth) ,
		info1 : u_info1,
		info2 : u_info2,
		info3 : u_info3,
		img : './IMAGE/' + u_img
	};
	return pCabinet;
}

function Part(u_Name,u_CabName,u_Mat,u_IsPanel,u_IsHardware) {
	var pPart = {
		Name: u_Name,
		CabName: u_CabName,
		Mat : u_Mat,
		IsPanel : u_IsPanel,
		IsHardware : u_IsHardware
	};
	return pPart;
}


 function GetCabinetbyName(u_Name) {
	for (var i = 0; i < cabs.length; i++) {
		var pCab = cabs[i];
		if (pCab.Name==u_Name)
		{	
			return pCab;
		}
	}
	return null;
}

function ClearArray(){
	cabs=new Array;
}



function InsertCabinet(u_Name,u_Num,u_Width,u_Height, u_Depth ,u_info1,u_info2,u_info3,u_img){
	
	var pCab=GetCabinetbyName(u_Name);
	if (u_Name=='&nbsp;'){
		return null;
	}
	if (pCab){
		return null;
	}
	else
	{
		pCab=Cabinet(u_Name,u_Num,u_Width,u_Height, u_Depth ,u_info1,u_info2,u_info3,u_img);
		cabs.push(pCab);
	}													
}

function InsertPart(u_Name,u_CabName,u_Mat,u_IsPanel,u_IsHardware){
	if (u_Name=='&nbsp;'){
		return null;
	}
	var pCab=GetCabinetbyName(u_CabName);
	if (!pCab){
		return null;
	}
	else
	{
		pPart=Part(u_Name,u_CabName,u_Mat,u_IsPanel,u_IsHardware);
		pCab.Parts.push(pPart);
	}													
}


function WriteCabinets(){
	cabfilter=GetCabNameFromUrl();
	var jsonsrc=GetjsonsrcFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteCabs(cabfilter);
	}
	else{
		loadScript(jsonsrc, myPrettyCode);
	}
};

function loadScript(url, callback)
{
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

    script.onreadystatechange = callback;
    script.onload = callback;

    head.appendChild(script);
}

var myPrettyCode = function() {WriteCabs(cabfilter);};



function WriteCabs(CFilter){
	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	jsond.parts.pop();
	
	for (var i = 0; i < jsond.cabs.length; i++) {
		var jcab=jsond.cabs[i];
		var pCab=GetCabinetbyName(jcab.cabname);
		if (!pCab){
			pCab=Cabinet(jcab.name,jcab.num,jcab.w,jcab.h, jcab.d ,jcab.info1,jcab.info2,jcab.info3,jcab.img);
			cabs.push(pCab);
		}
	}
	
	for (var i = 0; i < jsond.parts.length; i++) {
		var jpart=jsond.parts[i];
		var pCab=GetCabinetbyName(jpart.cabname);
		if (pCab){
			ppart=Part(jpart.name,jpart.cabname,jpart.mat,jpart.ispanel, jpart.ishardware);
			pCab.Parts.push(ppart);
		}
	}
	
	
	var out = document.getElementById('output');
	for (var i = 0; i < cabs.length; i++) {
		var pCab = cabs[i];
		if(CFilter==undefined || CFilter.length==0 || CFilter==pCab.Name ){
				WriteCab(pCab,out);
		}
	}
}

function WriteCab(pCab,out){
	var inHTML='';
	inHTML +=('<table class="table_corp_page">');
	
	inHTML +=('<tr><td>' + pCab.Name + ' ' +  pCab.Num + '</td></tr>');
	
	inHTML +=('<tr>');
	inHTML +=('<td>');
	
		inHTML +=('<table>');
			inHTML +=('<tr><td><img src="' + pCab.img + '" width="250" height="150" /></td></tr>');
			
			inHTML +=('<tr>');
				inHTML +=('<td>');
					inHTML +=('<table>');
					
						inHTML +=('<tr>');
						inHTML +=('<td><b>Cabinet Name</b></td>');
						inHTML +=('<td>' + pCab.Name + '</td>');
						inHTML +=('<td><b>Cabinet Info1</b></td>');
						inHTML +=('<td>' + pCab.info1 + '</td>');
						inHTML +=('</tr>');

						inHTML +=('<tr>');
						inHTML +=('<td><b>Cabinet Number</b></td>');
						inHTML +=('<td>' + pCab.Num + '</td>');
						inHTML +=('<td><b>Cabinet Info2</b></td>');
						inHTML +=('<td>' + pCab.info2 + '</td>');
						inHTML +=('</tr>');
						
						inHTML +=('<tr>');
						inHTML +=('<td><b>Cabinet Dimensions (WxDxH)</b></td>');
						inHTML +=('<td>' + pCab.Width + 'x' + pCab.Depth + 'x' + pCab.Height + '</td>');
						inHTML +=('<td><b>Cabinet Info3</b></td>');
						inHTML +=('<td>' + pCab.info3 + '</td>');
						inHTML +=('</tr>');
						
					inHTML +=('</table>');
				inHTML +=('</td>');
			inHTML +=('</tr>');
			inHTML +=('<tr>');
				inHTML +=('<td>');
				
					inHTML +=('<table>');
					
					inHTML +=('<tr><td>Panels</td></tr>');
					inHTML +=('<tr><td>');
					inHTML +=('<table>');
					for (var i = 0; i < pCab.Parts.length; i++) {
						if(pCab.Parts[i].IsPanel==1){
							inHTML +=('<tr>');
							inHTML +=('<td><b>Part Name</b></td>');
							inHTML +=('<td>'+ pCab.Parts[i].Name +'</td>');
							inHTML +=('<td><b>Material</b></td>');
							inHTML +=('<td>'+ pCab.Parts[i].Mat +'</td>');
							inHTML +=('</tr>');
						}
					}	
					inHTML +=('</table>');
					inHTML +=('</td></tr>');
					
					
					inHTML +=('<tr><td>Hardwares</td></tr>');
					inHTML +=('<tr><td>');
					inHTML +=('<table>');
					for (var i = 0; i < pCab.Parts.length; i++) {
						if(pCab.Parts[i].IsHardware==1){
							inHTML +=('<tr>');
							inHTML +=('<td><b>Part Name</b></td>');
							inHTML +=('<td>'+ pCab.Parts[i].Name +'</td>');
							inHTML +=('</tr>');
						}
					}	
					inHTML +=('</table>');
					inHTML +=('</td></tr>');
					
					inHTML +=('</table>');
					
				inHTML +=('</td>');
			
			inHTML +=('</tr>');
		inHTML +=('</table>');
	inHTML +=('</td>');
	inHTML +=('</tr>');
	inHTML +=('<tr><td></td></tr>');
	inHTML +=('<tr><td></td></tr>');
	inHTML +=('</table>');
	
	out.innerHTML+=inHTML;
}

/*function WriteCabs(CabFilter){
	for (var i = 0; i < cabs.length; i++) {
		var pCab = cabs[i];
		if(CabFilter==undefined || CabFilter.length==0 || CabFilter==pCab.Name ){
				WriteCab(pCab);
		}
	}
}*/

/*function WriteCab(pCab){
	///document.write('<tr><td align="left">'+ pCab.Name +'</td></tr>');
	//for (var i = 0; i < pCab.Parts.length; i++) {
	//	document.write('<tr><td align="right">'+ pCab.Parts[i].Name +'</td></tr>');
	//}		
	
	document.write('<table class="table_corp_page">');
	
	document.write('<tr><td">' + pCab.Name + ' ' +  pCab.Num + '</td></tr>');
	
	document.write('<tr>');
	document.write('<td">');
	
		document.write('<table>');
			document.write('<tr><td><img src="' + pCab.img + '" width="250" height="150" /></td></tr>');
			
			document.write('<tr>');
				document.write('<td>');
					document.write('<table>');
					
						document.write('<tr>');
						document.write('<td><b>Cabinet Name</b></td>');
						document.write('<td>' + pCab.Name + '</td>');
						document.write('<td><b>Cabinet Info1</b></td>');
						document.write('<td>' + pCab.info1 + '</td>');
						document.write('</tr>');

						document.write('<tr>');
						document.write('<td><b>Cabinet Number</b></td>');
						document.write('<td>' + pCab.Num + '</td>');
						document.write('<td><b>Cabinet Info2</b></td>');
						document.write('<td>' + pCab.info2 + '</td>');
						document.write('</tr>');
						
						document.write('<tr>');
						document.write('<td><b>Cabinet Dimensions (WxDxH)</b></td>');
						document.write('<td>' + pCab.Width + 'x' + pCab.Depth + 'x' + pCab.Height + '</td>');
						document.write('<td><b>Cabinet Info3</b></td>');
						document.write('<td>' + pCab.info3 + '</td>');
						document.write('</tr>');
						
					document.write('</table>');
				document.write('</td>');
			document.write('</tr>');
			document.write('<tr>');
				document.write('<td>');
				
					document.write('<table>');
					
					document.write('<tr><td>Panels</td></tr>');
					document.write('<tr><td>');
					document.write('<table>');
					for (var i = 0; i < pCab.Parts.length; i++) {
						if(pCab.Parts[i].IsPanel==1){
							document.write('<tr>');
							document.write('<td><b>Part Name</b></td>');
							document.write('<td>'+ pCab.Parts[i].Name +'</td>');
							document.write('<td><b>Material</b></td>');
							document.write('<td>'+ pCab.Parts[i].Mat +'</td>');
							document.write('</tr>');
						}
					}	
					document.write('</table>');
					document.write('</td></tr>');
					
					
					document.write('<tr><td>Hardwares</td></tr>');
					document.write('<tr><td>');
					document.write('<table>');
					for (var i = 0; i < pCab.Parts.length; i++) {
						if(pCab.Parts[i].IsHardware==1){
							document.write('<tr>');
							document.write('<td><b>Part Name</b></td>');
							document.write('<td>'+ pCab.Parts[i].Name +'</td>');
							document.write('</tr>');
						}
					}	
					document.write('</table>');
					document.write('</td></tr>');
					
					document.write('</table>');
					
				document.write('</td>');
			
			document.write('</tr>');
		document.write('</table>');
	document.write('</td>');
	document.write('</tr>');
	document.write('<tr><td></td></tr>');
	document.write('<tr><td></td></tr>');
	document.write('</table>');
}*/

