var Materials=new Array;
var Materials_1=new Array;
var Materials_2=new Array;

var Indice=0;
var Indice1=0;
var Indice2=0;
var pCostingEB=0;
var pCostingPan=0;
var pCostingHA=0;
var pCostingMaterialsSubCatTotal=0;
var pCostingMaterialsTotal=0;
var pCostingProgrammesTotal=0;
var currency;

var dict = {};


// Création du matériau avec ses variables (variables dans le même ordre que dans le fichier Report Material.html)
function Material(u_Name, u_Desc, u_Costfactor, u_LengthM, u_Width, u_Thickness, u_Costtype, u_Surf, u_Vol, u_Qte, u_GQte, u_Cost, u_Currency) {
    if (u_GQte == '0') {
        u_GQte = 1
    }
	var pMaterial = {Name: u_Name,Desc : u_Desc , Costfactor: u_Costfactor, LengthM : parseFloat(u_LengthM), Width: parseFloat(u_Width), Thickness: parseFloat(u_Thickness) , Costtype : u_Costtype, Surf : parseFloat(u_Surf), Vol : parseFloat(u_Vol), Qte: parseFloat(u_Qte), GQte: parseFloat(u_GQte), Cost:parseFloat(u_Cost), Currency: u_Currency };
	currency = u_Currency
	return pMaterial;
}

// Material_1: Chants
function Material_1(u_Name, u_Desc, u_Costfactor, u_LengthM, u_Width, u_Thickness, u_Costtype, u_Surf, u_Vol, u_Qte, u_GQte, u_Cost, u_Currency) {
    if (u_GQte == '0') {
        u_GQte = 1
    }
	var pMaterial_1 = {Name: u_Name,Desc : u_Desc , Costfactor: u_Costfactor, LengthM : parseFloat(u_LengthM), Width: parseFloat(u_Width), Thickness: parseFloat(u_Thickness) , Costtype : u_Costtype, Surf : parseFloat(u_Surf), Vol : parseFloat(u_Vol), Qte: parseFloat(u_Qte), GQte: parseFloat(u_GQte), Cost:parseFloat(u_Cost), Currency: u_Currency };
	return pMaterial_1;
}

// Material_2
function Material_2(u_Name, u_Desc, u_Costfactor, u_LengthM, u_Width, u_Thickness, u_Costtype, u_Surf, u_Vol, u_Qte, u_GQte, u_Cost, u_Currency) {
    if (u_GQte == '0') {
        u_GQte = 1
    }
	var pMaterial_2 = {Name: u_Name,Desc : u_Desc , Costfactor: u_Costfactor, LengthM : parseFloat(u_LengthM), Width: parseFloat(u_Width), Thickness: parseFloat(u_Thickness) , Costtype : u_Costtype, Surf : parseFloat(u_Surf), Vol : parseFloat(u_Vol), Qte: parseFloat(u_Qte), GQte: parseFloat(u_GQte), Cost: parseFloat(u_Cost), Currency: u_Currency};
	return pMaterial_2;
}

// Check les matériaux par leur nom, créée la variable pMat: regroupe les matériaux par leur nom: Panneaux
 function GetMaterialbyName(u_Name,u_Thickness) {
	for (var i = 0; i < Materials.length; i++) {
		var pMat = Materials[i];
		if (pMat.Name==u_Name)
		{	
			if (pMat.Thickness==u_Thickness)
			{
				return pMat;
			}
		}
	}
	return null;
}

function SumHardwareCost(hardwareCost) {
    if (pCostingHA) {
        pCostingHA += hardwareCost;
	}
	else {
		pCostingHA = hardwareCost;
	}
}

// Check les matériaux par leur nom, créée la variable pMat: regroupe les matériaux par leur nom: Chants
 function GetMaterialbyName_1(u_Name,u_Width) {
	for (var i1 = 0; i1 < Materials_1.length; i1++) {
		var pMat_1 = Materials_1[i1];
		if (pMat_1.Name==u_Name)
		{	
			if (pMat_1.Width==u_Width)
			{
				return pMat_1;
			}
		}
	}
	return null;
}

// Material 2
 function GetMaterialbyName_2(u_Name) { 
	for (var i2 = 0; i2 < Materials_2.length; i2++) {
		var pMat_2 = Materials_2[i2];
		if (pMat_2.Name==u_Name)
		{
			return pMat_2;
		}
	}
	return null;
 }

// Rempli la ligne actuelle du tableau material
function WriteMaterial(pMat){
	
	document.write('<tr>');
    //Nom
	document.write('<td><center>'+ pMat.Name +'<\center></td>');
    //Ep Panneau
	document.write('<td><center>'+ pMat.Thickness +'<\center></td>');
    //Description
    document.write('<td><center>' + pMat.Desc + '<\center></td>');
    //On ecrit le facteur de coût
    document.write('<td><center>' + pMat.GQte + '<\center></td>');
    
	var resultMat=0;
    var unitMat = "";
    //Si le type de cout est 1: Surfacique
	if (pMat.Costtype==1){
		resultMat=Math.round(pMat.Surf*1000)/1000;
		unitMat="m2";
	}
    //Sinon si le type de cout est 0: Volumique
	else if (pMat.Costtype==0)
	{
		resultMat=Math.round(pMat.Vol*1000)/1000;
		unitMat="m3";
	}
    //Sinon il est linéaire
	else 
	{
		resultMat=Math.round(pMat.LengthM)/1000;
		unitMat="m";
    }

    document.write('<td><center>' + resultMat + ' ' + unitMat + '<\center></td>');
    document.write('<td><center>' + Math.round(pMat.GQte * resultMat * 1000) / 1000 + ' ' + unitMat +'<\center></td>');
	//document.write('<td><center>'+unitMat+'<\center></td>');
	document.write('<td><center>'+pMat.Cost+' '+pMat.Currency+'<\center></td>');
    document.write('<td><center>' + Math.round(pMat.GQte * resultMat * pMat.Cost * 1000) / 1000 + ' ' + pMat.Currency + '<\center></td>');
    pCostingMaterialsSubCatTotal += Math.round(pMat.GQte * resultMat * pMat.Cost * 1000) / 1000 //total matériaux
    pCostingMaterialsTotal += Math.round(pMat.GQte * resultMat * pMat.Cost * 1000) / 1000 //sous total (panneau/laminé/massif/verre)
	document.write('</tr>');													
}	

// Remplit la ligne actuelle du tableau material_1: Chants
function WriteMaterial_1(pMat_1){
	document.write('<tr>');
    //Nom
	document.write('<td><center>'+ pMat_1.Name +'<\center></td>');
    //Ep Panneau
	document.write('<td><center>'+ pMat_1.Width +'<\center></td>');
    //Description
    document.write('<td><center>' + pMat_1.Desc + '<\center></td>');
    //On ecrit le facteur de coût
    document.write('<td><center>' + pMat_1.GQte + '<\center></td>');
    //toujours linéaire
	document.write('<td><center>'+ Math.round(pMat_1.LengthM)/1000 + ' m' + '<\center></td>');
    //On écrit le brut (net*costfactor)
	document.write('<td><center>'+ Math.round(pMat_1.GQte*pMat_1.LengthM)/1000+ ' m' + '<\center></td>');
	//document.write('<td><center>m<\center></td>');
	document.write('<td><center>'+ pMat_1.Cost+' '+pMat_1.Currency+ '<\center></td>');
    document.write('<td><center>' + Math.round(pMat_1.GQte * pMat_1.LengthM*pMat_1.Cost) / 1000 + ' ' + pMat_1.Currency + '<\center></td>');	
    pCostingMaterialsTotal += Math.round(pMat_1.GQte * pMat_1.LengthM*pMat_1.Cost) / 1000 //total matériaux
    pCostingMaterialsSubCatTotal += Math.round(pMat_1.GQte * pMat_1.LengthM*pMat_1.Cost) / 1000 //sous total chants
	document.write('</tr>');													
}

//Mise à jour du tableau Material: pMat,pSurf, pVol
function UpdateMaterial(u_Name, u_Desc, u_Costfactor, u_LengthM, u_Width, u_Thickness, u_Costtype, u_Qte, u_Gqte, u_Cost, u_Currency){
	var pMat=GetMaterialbyName(u_Name,u_Thickness);
	var pSurf=((u_LengthM*u_Width)/1000000);
	var pVol=((pSurf*u_Thickness)/1000);
	if (u_Name=='&nbsp;'){
		return null;
	}
//Si pMat existe: ancienne valeur + nouvelle
	if (pMat){
		pMat.Surf=pMat.Surf+(pSurf*u_Qte);
		pMat.Vol=pMat.Vol+(pVol*u_Qte);
		pMat.LengthM=pMat.LengthM + (u_LengthM*u_Qte);
	}
//Sinon on crée pMat et on initialise pMat.X=pX*u_Qte
	else
	{
		pMat=Material(u_Name,u_Desc,u_Costfactor,u_LengthM,u_Width,u_Thickness,u_Costtype, pSurf, pVol, u_Qte, u_Gqte, u_Cost, u_Currency);
		pMat.Surf=pSurf*u_Qte;
		pMat.Vol=pVol*u_Qte;
		pMat.LengthM=u_LengthM*u_Qte;
		Materials[Indice]=pMat;
		Indice++;
	}													
}

//Mise à jour du tableau Material: pMat,pSurf, pVol: Chants
function UpdateMaterial_1(u_Name, u_Desc, u_Costfactor, u_LengthM, u_Width, u_Thickness, u_Costtype, u_Qte, u_Gqte, u_Cost, u_Currency){
	var pMat_1=GetMaterialbyName_1(u_Name,u_Width);
	var pSurf=((u_LengthM*u_Width)/1000000);
	var pVol=((pSurf*u_Thickness)/1000);
	if (u_Name=='&nbsp;'){
		return null;
	}
//Si pMat_1 existe: ancienne valeur + nouvelle
	if (pMat_1){
		pMat_1.Surf=pMat_1.Surf+(pSurf*u_Qte);
		pMat_1.Vol=pMat_1.Vol+(pVol*u_Qte);
		pMat_1.LengthM=pMat_1.LengthM + (u_LengthM*u_Qte);
	}
//Sinon on crée pMat_1 et on initialise pMat_1.X=pX*u_Qte
	else
	{
		pMat_1=Material_1(u_Name,u_Desc,u_Costfactor,u_LengthM,u_Width,u_Thickness,u_Costtype, pSurf, pVol, u_Qte, u_Gqte, u_Cost, u_Currency);
		pMat_1.Surf=pSurf*u_Qte;
		pMat_1.Vol=pVol*u_Qte;
		pMat_1.LengthM=u_LengthM*u_Qte;
		Materials_1[Indice1]=pMat_1;
		Indice1++;
	}													
}

function WriteMaterialsArrayHeaders() {
    document.write('<tr class="cellule_menu"></tr>');
    document.write('<tr class="font_page">');
    document.write('<td align="left" class="corp_page_debits">');
    document.write('<div class="print">');
    document.write('<table border="1" cellspacing="0.5" width="100%" id="cadre_tableau_debit">');
    document.write('<tr style="height:25px;vertical-align:middle" id="tableau_debit_title">');
    document.write('<td width="10%"><b>' + dict.Material + '</b></td>');
    document.write('<td width="10%"><b>' + dict.PanelThickness + '</b></td>');
    document.write('<td width="10%"><b>' + dict.Description + '</b></td>');
    document.write('<td width="10%"><b>' + dict.ProjectCount + '</b></td>');
    document.write('<td width="10%"><b>' + dict.QTYproject + '</b></td>');    
    document.write('<td width="10%"><b>' + dict.QTY + '</b></td>');
    //document.write('<td width="10%"><b>' + dict.UnitOfMeasure + '</b></td>');
    document.write('<td width="10%"><b>' + dict.UnitCost + '</b></td>');
    document.write('<td width="10%"><b>' + dict.TotalCost + '</b></td>');
}

function WriteMaterialsArray(type) {
    if (Materials.length > 0) {
        var id;
        if (type == dict.Panels) {
            id = 'Panels';
        }
        else if (type == dict.Laminates) {
            id = 'Laminates';
        }
        else if (type == dict.Hardwood) {
            id = 'Hardwood';
        }
        else if (type == dict.Edgebands) {
            id = 'Edgebands';
        }
        else if (type == dict.Glass) {
            id = 'Glass';
        }

        document.write('<tr style="height:25px;background-color:lightgrey">');
        document.write('<td colspan="7" style="font-size:15px;border:none"><center>' + type.toUpperCase() + '</center></td >');
        document.write('<td colspan="1" id="cost' + id +'" style="font-weight:bold;border:none"></td>');
        document.write('</tr>');

        pCostingMaterialsSubCatTotal = 0
        for (var i = 0; i < Materials.length; i++) {
            var pMat = Materials[i];
            WriteMaterial(pMat);
        }
        document.getElementById('cost' + id).innerHTML = '<center>' + pCostingMaterialsSubCatTotal + ' ' + currency + '</center>'
    }
}


// Ecrit le tableau Material à la fin - Tableau chants
function WriteMaterialsArray_1(type) {
    if (Materials_1.length > 0) {
        var id;
        if (type == dict.Panels) {
            id = 'Panels';
        }
        else if (type == dict.Laminates) {
            id = 'Laminates';
        }
        else if (type == dict.Hardwood) {
            id = 'Hardwood';
        }
        else if (type == dict.Edgebands) {
            id = 'Edgebands';
        }
        else if (type == dict.Glass) {
            id = 'Glass';
        }
        document.write('<tr style="height:25px;background-color:lightgrey">');
        document.write('<td colspan="7" style="font-size:15px;border:none"><center>' + type.toUpperCase() + '</center></td>');
        document.write('<td colspan="1" id="cost' + id +'" style="font-weight:bold;border:none"></td>');
        document.write('</tr>');

        pCostingMaterialsSubCatTotal = 0
        for (var i1 = 0; i1 < Materials_1.length; i1++) {
            var pMat_1 = Materials_1[i1];
            WriteMaterial_1(pMat_1);
        }
        document.getElementById('cost' + id).innerHTML = '<center>' + pCostingMaterialsSubCatTotal + ' ' + currency + '</center>'
    }
}

// Vide le tableau Materials après l'avoir écrit, remet l'indice de la ligne du tableau à 0, sinon décalage entre la ligne et la taille du tableau!
function ClearArray(){
	Materials=new Array;
	Indice=0;
}

var MacCostArray=new Array;

function MacCost(u_MacName, u_Cost) {
	var pMacCost = {Name: u_MacName, Cost:parseFloat(u_Cost)};
	return pMacCost;
}

function UpdateMacCost(u_MacName, u_Cost){
	var pMacCost=GetMacCostbyName(u_MacName);
	if (u_MacName=='&nbsp;'){
		return null;
	}
	if (pMacCost){
	}
	else
	{
		pMacCost=MacCost(u_MacName,u_Cost);
		MacCostArray[MacCostArray.length]=pMacCost;
	}													
}

 function GetMacCostbyName(u_MacName) {
	for (var i = 0; i < MacCostArray.length; i++) {
		var pMacCost = MacCostArray[i];
		if (pMacCost.Name==u_MacName)
		{	
			return pMacCost;
		}
	}
	return null;
}

 function GetMacCostValuebyName(u_MacName) {
	for (var i = 0; i < MacCostArray.length; i++) {
		var pMacCost = MacCostArray[i];
		if (pMacCost.Name==u_MacName)
		{	
			return pMacCost.Cost;
		}
	}
	return 0;
}

function ProgSubTotal(macCost) {
    if (pCostingProgrammesTotal) {
        pCostingProgrammesTotal += macCost;
    }
    else {
        pCostingProgrammesTotal = macCost;
    }
}

function DisplaySubCost(type) {
    var htmlID;
    var cost;
    if (type == dict.Materials && pCostingMaterialsTotal) {
        htmlID = 'costMaterials';
        cost = CurrencyRound(pCostingMaterialsTotal)
    }
    else if (type == dict.Hardwares && pCostingHA) {
        htmlID = 'costHA';
        cost = CurrencyRound(pCostingHA)
    }
    else if (type == dict.Programs && pCostingProgrammesTotal) {
        htmlID = 'costProg';
        cost = CurrencyRound(pCostingProgrammesTotal)
    }
    else {
        return;
    }
    document.getElementById(htmlID).innerHTML = '<center>' + cost + ' ' + currency + '</center>'
}

function DisplayTotal(totalType) {
    var cost;
   
    if (totalType == dict.MaterialsCost) {
        cost = CurrencyRound(pCostingMaterialsTotal);
    }
    else if (totalType == dict.HardwaresCost) {
        cost = CurrencyRound(pCostingHA);
    }
    else if (totalType == dict.ProgramsCost) {
        cost = CurrencyRound(pCostingProgrammesTotal);
    }
    else if (totalType == dict.TotalCost) {
        cost = CurrencyRound(pCostingHA + pCostingProgrammesTotal + pCostingMaterialsTotal);
    }
    else {
        return;
    }

    document.write('<tr class="cellule_menu">');
    document.write('<td width="100%" align="left">');
    document.write('<div>');
    document.write('<table border="0" cellspacing="0.5" width="100%">');
    document.write('<tr>');
    document.write('<td height="20" align="Left" valign="middle"><a style="text-decoration:none; color:#FFFFFF">' + totalType + '</a></td>');
    document.write('<td align="right">' + cost + ' ' + currency + '</td>');
    document.write('</tr>');
    document.write('</table>');
    document.write('</div>');
    document.write('</td>');
    document.write('</tr>');
}

function CurrencyRound(value) {
    return parseFloat(Math.round(value * 100) / 100).toFixed(2);
}

function InitializeDictEN() {
    //Materials
    dict['Materials'] = 'Materials';
    dict['Panels'] = 'Panels';
    dict['Laminates'] = 'Laminates';
    dict['Edgebands'] = 'Edgebands';
    dict['Hardwood'] = 'Hardwood';
    dict['Glass'] = 'Glass';
    dict['Material'] = 'Material';
    dict['PanelThickness'] = 'Panel Thickness';
    dict['Description'] = 'Description';
    dict['QTYproject'] = 'Quantity per project';
    dict['ProjectCount'] = 'Project Count';
    dict['QTY'] = 'Total Quantity';
    dict['UnitOfMeasure'] = 'Unit of measure';
    dict['UnitCost'] = 'Unit Cost';
    dict['TotalCost'] = 'Total Cost';

    //Hardwares
    dict['Hardwares'] = 'Hardwares';
    dict['Supplier'] = 'Supplier';
    dict['Reference'] = 'Reference';

    //Programs
    dict['Programs'] = 'Programs';
    dict['Machine'] = 'Machine';
    dict['Quantity'] = 'Quantity';
    dict['ProgramDuration'] = 'Program duration (min)';
    dict['HourlyCost'] = 'Hourly Cost';

    //Totals
    dict['MaterialsCost'] = 'Materials Cost';
    dict['HardwaresCost'] = 'Hardwares Cost';
    dict['ProgramsCost'] = 'Programs Cost';
}

function InitializeDictFR() {
    //Materials
    dict['Materials'] = 'Matériaux';
    dict['Panels'] = 'Panneaux';
    dict['Laminates'] = 'Laminés';
    dict['Edgebands'] = 'Chants';
    dict['Hardwood'] = 'Massif';
    dict['Glass'] = 'Verre';
    dict['Material'] = 'Matériau';
    dict['PanelThickness'] = 'Epaisseur du panneau';
    dict['Description'] = 'Description';
    dict['QTYproject'] = 'Quantité par projet';
    dict['ProjectCount'] = 'Nombre de projets';
    dict['QTY'] = 'Quantité totale';
    dict['UnitOfMeasure'] = 'Unité de mesure';
    dict['UnitCost'] = 'Coût unitaire';
    dict['TotalCost'] = 'Coût total';

    //Hardwares
    dict['Hardwares'] = 'Quincaillerie';
    dict['Supplier'] = 'Fournisseur';
    dict['Reference'] = 'Référence';

    //Programs
    dict['Programs'] = 'Programmes';
    dict['Machine'] = 'Machine';
    dict['Quantity'] = 'Quantité';
    dict['ProgramDuration'] = 'Durée du programme (min)';
    dict['HourlyCost'] = 'Coût horaire';

    //Totals
    dict['MaterialsCost'] = 'Coût des matériaux';
    dict['HardwaresCost'] = 'Coût de la quincaillerie';
    dict['ProgramsCost'] = 'Coût des programmes';
}
	

