var cabfilter='';
var progfilter='';
var jsonsrc='';


function GetParametersFromUrl(){	
	if(typeof String.prototype.trim !== 'function') {
	  String.prototype.trim = function() {
		return this.replace(/^\s+|\s+$/g, ''); 
	  }
	}
	if(typeof String.prototype.startsWith !== 'function') {
	  String.prototype.startsWith = function (str)
	  {
		 return this.indexOf(str) == 0;
	  }
	}
	if(typeof String.prototype.endsWith !== 'function') {
	  String.prototype.endsWith = function (str)
	  {
		 return this.indexOf(str, this.length - str.length) !== -1;
	  }
	}

	cabfilter='';
	progfilter='';
	jsonsrc='';
	var t = location.search.substring(1).split('&');
		for (var i=0; i<t.length; i++){
		var x = t[i].split('=');
		if(x[0]=='cabname'){
			cabfilter=x[1];
			//cabfilter=cabfilter.replace('%20',' ');
			cabfilter=cabfilter.trim();
			if(cabfilter.startsWith("%22") && cabfilter.endsWith("%22")){
				cabfilter=cabfilter.substring(3, cabfilter.length-3);
			}
		cabfilter=decodeURIComponent(cabfilter);
		}
		else if(x[0]=='progname'){
			progfilter=x[1];
			//progfilter=progfilter.replace('%20',' ');
			progfilter=progfilter.trim();
			if(progfilter.startsWith("%22") && progfilter.endsWith("%22")){
				progfilter=progfilter.substring(3, progfilter.length-3);
			}
		progfilter=decodeURIComponent(progfilter);
		}
		else if(x[0]=='jsonsrc'){
			jsonsrc=x[1];
			jsonsrc=jsonsrc.trim();
			if(jsonsrc.startsWith("%22") && jsonsrc.endsWith("%22")){
				jsonsrc=jsonsrc.substring(3, jsonsrc.length-3);
				
			}
			jsonsrc=decodeURIComponent(jsonsrc);
		}
	}
};

function GetHardware(jsondata,p_Name,p_Conf,p_ModelType) {
	 if(jsondata!=null){
		for (var i = 0; i < jsondata.hardwares.length; i++) {
			var phard = jsondata.hardwares[i];
			if (phard.name==p_Name && phard.conf==p_Conf  && phard.swtype==p_ModelType )
			{	
				return phard;
			}
		}
	 }
	return null;
};

function GetPanel(jsondata,p_Name,p_Conf) {
	 if(jsondata!=null){
		for (var i = 0; i < jsondata.panels.length; i++) {
			var pPanel = jsondata.panels[i];
			if (pPanel.name==p_Name && pPanel.conf==p_Conf )
			{	
				return pPanel;
			}
		}
	 }
	return null;
};

function GetMaterial(jsondata,p_Name) {
	 if(jsondata!=null){
		for (var i = 0; i < jsondata.mat.length; i++) {
			var pMat = jsondata.mat[i];
			if (pMat.name==p_Name)
			{	
				return pMat;
			}
		}
	 }
	return null;
};

function GetEdgeband(jsondata,p_ebid) {
	 if(jsondata!=null){
		for (var i = 0; i < jsondata.ebmat.length; i++) {
			var pMat = jsondata.ebmat[i];
			if (pMat.id==p_ebid)
			{	
				return pMat;
			}
		}
	 }
	return null;
};

function GetProgNest(jsondata,p_Name,p_Id) {
	 if(jsondata!=null){
		for (var i = 0; i < jsondata.nest.length; i++) {
			var pNest = jsondata.nest[i];
			if (pNest.name==p_Name && pnest.id==p_Id )
			{	
				return pNest;
			}
		}
	 }
	return null;
};


function loadScript(url, callback){
    var head = document.getElementsByTagName('head')[0];
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;

    script.onreadystatechange = callback;
    script.onload = callback;

    head.appendChild(script);
};


function WriteProjectDetails(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteProjDet();
	}
	else{
		loadScript(jsonsrc, function() {WriteProjDet();});
	}
};

function WriteProjDet(){
	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	
	var srcfilename = jsonsrc.substring(jsonsrc.lastIndexOf('/')+1);
	var docsdirectory = jsonsrc.substring(0,jsonsrc.lastIndexOf('/'));


	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Project Details<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="imgcontainer"><img src="' + docsdirectory + "/IMAGE/" + jsond.project.img + '" width="200" height="200" /></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content boldcontent"><tr><td><p>Width: ' + jsond.project.w + '</p><p>Depth: ' + jsond.project.d + '</p><p>Height: ' + jsond.project.h + '</p></td><td><p>Comment1: ' + jsond.project.info1 + '</p><p>Comment2: ' + jsond.project.info2 + '</p><p>Comment3: ' + jsond.project.info3 + '</p></td><td><p>Order: ' + jsond.project.order + '</p><p>Customer: ' + jsond.project.cust + '</p><p>Work Number: ' + jsond.project.work_nb + '</p></td></tr></table>');//colonnes non identifiées <td><p>?1: 1</p><p>?2: 1</p><p>?3: 1</p></td>//
	inHTML +=('<div class="separator"></div>');
	inHTML +='</div>';
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};


function WriteCabinetList(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteCabsList();
	}
	else{
		loadScript(jsonsrc, function() {WriteCabsList();});
	}
};

function WriteCabsList(){
	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	
	var srcfilename = jsonsrc.substring(jsonsrc.lastIndexOf('/')+1);
	var docsdirectory = jsonsrc.substring(0,jsonsrc.lastIndexOf('/'));


	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Cabinet list<p></div>');
	inHTML +=('<div class="separator"></div>');
	
	inHTML +=('<table class="content" style="width:100%;"');
	
	for (var i = 0; i < jsond.cabs.length; i++) {
		var pCab=jsond.cabs[i];

		inHTML +=('<tr>');
		inHTML +=('<td rowspan="3" align="center">');
		inHTML +=('<a href="./ReportCabinet.html?cabname=' + pCab.name + '&jsonsrc=%22' + jsonsrc + '%22">');
		inHTML +=('<img src="' + docsdirectory + "/IMAGE/" + pCab.img + '" width="200" height="200" border="0" />');
		inHTML +=('</a>');
		inHTML +=('</td>');
		inHTML +=('<td><p>Name: ' + pCab.name + '</p></td>' );
		inHTML +=('<td><p>Info1: ' + pCab.info1 + '</p></td>' );
		inHTML +=('</tr>');
		
		inHTML +=('<tr>');
		inHTML +=('<td><p>Number: ' + pCab.num + '</p></td>' );
		inHTML +=('<td><p>Info2: ' + pCab.info2 + '</p></td>' );
		inHTML +=('</tr>');
		
		inHTML +=('<tr>');
		inHTML +=('<td><p>Cabinet Dimensions (WxDxH): ' + pCab.w + 'x' +  pCab.d + 'x' +  pCab.h   + '</p></td>' );
		inHTML +=('<td><p>Info3: ' + pCab.info3 + '</p></td>' );
		inHTML +=('</tr>');
	}
	inHTML +='</table>';
	inHTML +='</div>';
	out.innerHTML=inHTML;
};

function WriteCabinets(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteCabs(cabfilter);
	}
	else{
		loadScript(jsonsrc, function() {WriteCabs(cabfilter);});
	}
};

function WriteCabs(CFilter){
	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	jsond.panels.pop();
	jsond.hardwares.pop();
	
	for (var i = 0; i < jsond.panels.length; i++) {
		var pPanel = jsond.panels[i];
		pPanel.cncprgww='';
		pPanel.cncprgmorbi='';
		pPanel.prgs.pop();
		if(pPanel.prgs.length>0){
			for (var j = 0; j < pPanel.prgs.length; j++) {
				if(pPanel.prgs[j].mac.indexOf('WOODWOP')==0){
					if(pPanel.cncprgww==''){
						pPanel.cncprgww=pPanel.prgs[j].name;
					}
					else{
						pPanel.cncprgww+= ", " + pPanel.prgs[j].name;
					}
				}
				else if(pPanel.prgs[j].mac.indexOf('MORBIDELLI')==0){
					if(pPanel.cncprgmorbi==''){
						pPanel.cncprgmorbi=pPanel.prgs[j].name;
					}
					else{
						pPanel.cncprgmorbi+= ", " + pPanel.prgs[j].name;
					}
				}
			}
		}
	}
	
	
	var srcfilename = jsonsrc.substring(jsonsrc.lastIndexOf('/')+1);
	var docsdirectory = jsonsrc.substring(0,jsonsrc.lastIndexOf('/'));


	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	for (var i = 0; i < jsond.cabs.length; i++) {
		var pCab = jsond.cabs[i];
		pCab.img=docsdirectory + "/IMAGE/" + pCab.img;
		if(CFilter==undefined || CFilter.length==0 || CFilter==pCab.name ){
			inHTML+=WriteCab(jsond,pCab,inHTML);
			j=j+1;
		}
	}
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};

function WriteCab(jsond,pCab){
	
	var inHTML='';
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Cabinet number: ' + pCab.num + '<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content boldcontent"><tr><td><p>Name: ' + pCab.name + '</p></td><td><p>Qty: ' + pCab.qty + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content boldcontent"><tr><td><p>Width: ' + pCab.w + jsond.project.lengthunit +'</p><p>Depth: ' + pCab.d + jsond.project.lengthunit +'</p><p>Height: ' + pCab.h + jsond.project.lengthunit + '</p></td><td><p>Order: ' + jsond.project.order + '</p><p>Customer: ' + jsond.project.cust + '</p><p>Weight: ' + pCab.weight + jsond.project.weightunit+'</p></td></tr></table>');//colonnes non identifiées <td><p>?1: 1</p><p>?2: 1</p><p>?3: 1</p></td>//
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="imgcontainer"><img src="' + pCab.img + '" alt="' + pCab.name + '" title="' + pCab.name + '" width="200" height="200" /></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"  style="width:100%;">');
	inHTML +=('<tr><td rowspan="2"><p>Material</p></td><td rowspan="2"><p>Part</p></td><td colspan="3"><p style="text-align:center;">Final Dimension</p></td><td rowspan="2"><p>Qty</p></td><td rowspan="2"><p>Total</p><p>Qty</p></td></tr>');
	inHTML +=('<tr><td><p>Length</p></td><td><p>Width</p></td><td><p>Thickness</p></td></tr>');
	
	for (var i = 0; i < pCab.panels.length-1; i++) {
		var ppanel=pCab.panels[i];
		var ppaneldata=GetPanel(jsond,ppanel.name,ppanel.conf);
		if(ppaneldata!=null){
			inHTML +=('<tr><td><p><i>' + ppaneldata.mat + '</i></p></td><td><p>' + ppaneldata.desc + '</p></td><td><p>' + ppaneldata.l + '</p></td><td><p>' + ppaneldata.w + '</p></td><td><p>' + ppaneldata.t + '</p></td><td><p>'+ ppanel.qty +'</p></td><td><p>'+ ppanel.qty*pCab.qty +'</p></td></tr>');
		}
	}
	
	
	
	inHTML +=('</table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content">');
	inHTML +=('<tr><td><p>Name</p></td><td><p>Reference</p></td><td><p>Supplier</p></td><td><p>Unit Cost</p></td><td><p>Qty</p></td><td><p>Total</p><p>Qty</p></td></tr>');
	for (var i = 0; i < pCab.hardwares.length-1; i++) {
		var phw=pCab.hardwares[i];
		if(phw!=null){
			inHTML +=('<tr><td><p>' + phw.name + '</p></td><td><p>' + phw.ref + '</p></td><td><p>' + phw.supplier + '</p></td><td><p>' + phw.ucost + '</p></td><td><p>' + phw.qty + '</p></td><td><p>' + phw.qty*pCab.qty + '</p></td></tr>');
		}
	}
	inHTML +=('</table>');
	inHTML +=('</div>');
	return inHTML;
};


function WritePanels(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WritePans();
	}
	else{
		loadScript(jsonsrc, function() {WritePans();});
	}
};
//var WritePansCB = function() {WritePans();};
function WritePans(){

	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	jsond.panels.pop();
	jsond.hardwares.pop();
	

	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	var ebn=['ebf','ebr','ebb','ebl'];
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Panels summary<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"  style="width:100%;">');
	inHTML +=('<tr><td rowspan="2"><p>Edgebands</p></td><td><p>Material</p></td><td colspan="2"><p style="text-align:center;">Final Dimension</p></td><td rowspan="2"><p>Qty</p></td><td rowspan="2"><p>Where used</p></td></tr>');
	inHTML +=('<tr><td><p>Picture</p></td><td><p>Length</p></td><td><p>Width</p></td></tr>');
			
			
	for (var i = 0; i < jsond.panels.length; i++) {
		var ppanel = jsond.panels[i];
		if(ppanel!=null){
			inHTML +=('<tr class="groupcontent"><td><p></p></td><td><p>' + ppanel.mat + '</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr>');
			inHTML +=('<tr class="groupcontent"><td><p>&nbsp;</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
			var matname=ppanel.mat;
			var mat= GetMaterial(jsond,ppanel.mat);
			var ebs=[];
			var pans=[];

			for (var j = i; j < jsond.panels.length; j++) {
				ppanel=jsond.panels[j];
				if(ppanel!=null){
					if(ppanel.mat==matname){
						jsond.panels[j]=null;
						pans.push(ppanel);
						for (var n = 0; n < 4; n ++) {
							if(pans[pans.length-1][ebn[n]]!=''){
								var ebid=pans[pans.length-1][ebn[n]];
								pans[pans.length-1][ebn[n]]='';
								for (var k = 0; k < ebs.length; k++) {
									if(ebs[k].id==ebid){
										pans[pans.length-1][ebn[n]]=k+1;
									}
								}
								if(pans[pans.length-1][ebn[n]]==''){
									var ebmat=GetEdgeband(jsond,ebid);
									if(ebmat!=null){
										ebs.push(ebmat);
										pans[pans.length-1][ebn[n]]=ebs.length;
									}
								}
							}
						}
					}
				}
			}
			var left=true;
			for (var j = 0; j < pans.length; j++) {
				ppanel=pans[j];
				if(j<ebs.length){
					inHTML +=('<tr class="groupcontent"><td><p>('+ (j+1)  + ') ' + ebs[j].desc + '</p></td>');
				}
				else{
					inHTML +=('<tr class="groupcontent"><td><p></p></td>');
				}
				
				inHTML +=('<td class="panelshema">');
				if(left){
					inHTML +=('<div class="panelshema panelshemaleft">');
				}
				else{
					inHTML +=('<div class="panelshema panelshemaright">');
				}
				if(mat!=null && mat.withgrain==1){
					if(ppanel.gisv==1){
						inHTML +=('<div class="panelshemagdv panelshemagdvleft"></div>');
						inHTML +=('<div class="panelshemagdv panelshemagdvright"></div>');
					}
					else{
						inHTML +=('<div class="panelshemagdh"></div>');
					}
				}
				if(ppanel.ebf!=''){
					inHTML +=('<div class="panelshemaedge panelshemaedgefront">' + ppanel.ebf + '</div>');
				}
				if(ppanel.ebb!=''){
					inHTML +=('<div class="panelshemaedge panelshemaedgeback">' + ppanel.ebb + '</div>');
				}
				if(ppanel.ebr!=''){
					inHTML +=('<div class="panelshemaedge panelshemaedgeright">' + ppanel.ebr + '</div>');
				}
				if(ppanel.ebl!=''){
					inHTML +=('<div class="panelshemaedge panelshemaedgeleft">' + ppanel.ebl + '</div>');
				}
				inHTML +=('</div>');
				inHTML +=('</td>');
				inHTML +=('<td><p>' + ppanel.l + '</p></td><td><p>' + ppanel.w + '</p></td><td><p>' + ppanel.qty + '</p></td><td><p>' + ppanel.namecab + '</p></td></tr>');
				left=!left;
			}
			for (var j = pans.length; j < ebs.length; j++) {
				inHTML +=('<tr class="groupcontent"><td><p>('+ (j+1)  + ') ' + ebs[j].desc + '</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
			}
			inHTML +=('<tr class="grouplast"><td><p>&nbsp;</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
		}
	}
	inHTML +=('</table>');
	inHTML +=('</div>');
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};

function WriteMillwork(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteMill();
	}
	else{
		loadScript(jsonsrc, function() {WriteMill();});
	}
};
//var WriteMillCB = function() {WriteMill();};
function WriteMill(){

	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	jsond.panelstwo.pop();
	jsond.hardwares.pop();
	

	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	var ebn=['ebf','ebr','ebb','ebl'];
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Millwork summary<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"  style="width:100%;">');
	inHTML +=('<tr><td rowspan="2"><p>Material</p></td><td rowspan="2"><p>ID</p></td><td colspan="3"><p style="text-align:center;">Final Dimension</p></td><td rowspan="2"><p>Qty</p></td><td rowspan="2"><p>Reference</p></td></tr>');
	inHTML +=('<tr><td><p>Thickness</p></td><td><p>Width</p></td><td><p>Length</p></td></tr>');
			
			
	for (var i = 0; i < jsond.panelstwo.length; i++) {
		var ppanel = jsond.panelstwo[i];
		if(ppanel!=null){
			
			inHTML +=('<tr class="groupcontent"><td><p>' + ppanel.mat + '</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr>');
			var matname=ppanel.mat;
			var mat= GetMaterial(jsond,ppanel.mat);
			var ebs=[];
			var pans=[];

			for (var j = i; j < jsond.panelstwo.length; j++) {
				ppanel=jsond.panelstwo[j];
				if(ppanel!=null){
					if(ppanel.mat==matname){
						jsond.panelstwo[j]=null;
						pans.push(ppanel);
						for (var n = 0; n < 4; n ++) {
							if(pans[pans.length-1][ebn[n]]!=''){
								var ebid=pans[pans.length-1][ebn[n]];
								pans[pans.length-1][ebn[n]]='';
								for (var k = 0; k < ebs.length; k++) {
									if(ebs[k].id==ebid){
										pans[pans.length-1][ebn[n]]=k+1;
									}
								}
								if(pans[pans.length-1][ebn[n]]==''){
									var ebmat=GetEdgeband(jsond,ebid);
									if(ebmat!=null){
										ebs.push(ebmat);
										pans[pans.length-1][ebn[n]]=ebs.length;
									}
								}
							}
						}
					}
				}
			}
			var left=true;
			for (var j = 0; j < pans.length; j++) {
				ppanel=pans[j];
				
				inHTML +=('<tr class="groupcontent"><td><p></p></td>');
				
				inHTML +=('<td><p>' + ppanel.id + '</p></td><td><p>' + ppanel.t + '</p></td><td><p>' + ppanel.w + '</p></td><td><p>' + ppanel.l + '</p></td><td><p>' + ppanel.qty + '</p></td><td><p>' + ppanel.ref + '</p></td></tr>');
				left=!left;
			}
			for (var j = pans.length; j < ebs.length; j++) {
				inHTML +=('<tr class="groupcontent"><td><p>('+ (j+1)  + ') ' + ebs[j].desc + '</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
			}
			inHTML +=('<tr class="grouplast"><td><p>&nbsp;</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
		}
	}
	inHTML +=('</table>');
	inHTML +=('</div>');
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};


function WriteCNCSUMMARY(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteCNC();
	}
	else{
		loadScript(jsonsrc, function() {WriteCNC();});
	}
};
//var CNCSUMMARYCB = function() {WriteCNC();};
function WriteCNC(){

	var jsond = JSON.parse(jsondata);
	jsond.nest.pop();
	

	var out = document.getElementById('output');
	var j=0;
	var pNestQtyTot=0;
	var inHTML='';
	var ebn=['ebf','ebr','ebb','ebl'];
	
	for (var i = 0; i < jsond.nest.length; i++) {
		var pNest=jsond.nest[i];
		pNestQtyTot=Number(pNestQtyTot)+Number(pNest.qty);
	}
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>CNC summary<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"  style="width:100%;">');
	inHTML +=('<tr><td rowspan="2"><p>Board name</p></td><td colspan="3"><p style="text-align:center;">Board dimensions</p></td><td colspan="1" style="text-align:center;">Total Sheets: ' + Number(pNestQtyTot) + '</td></tr>');
	inHTML +=('<tr><td><p>Thickness</p></td><td><p>Width</p></td><td><p>Length</p></td><td><p>Qty</p></td></tr>');
			
			
	for (var i = 0; i < jsond.nest.length; i++) {
		var pNest = jsond.nest[i];
		if(pNest!=null){
			
			inHTML +=('<tr class="groupcontent"><td><p>' + pNest.mat + '</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr>');
			var matname=pNest.mat;
			var mat= GetMaterial(jsond,pNest.mat);
			var ebs=[];
			var pans=[];

			for (var j = i; j < jsond.nest.length; j++) {
				pNest=jsond.nest[j];
				if(pNest!=null){
					if(pNest.mat==matname){
						jsond.nest[j]=null;
						pans.push(pNest);
						for (var n = 0; n < 4; n ++) {
							if(pans[pans.length-1][ebn[n]]!=''){
								var ebid=pans[pans.length-1][ebn[n]];
								pans[pans.length-1][ebn[n]]='';
								for (var k = 0; k < ebs.length; k++) {
									if(ebs[k].id==ebid){
										pans[pans.length-1][ebn[n]]=k+1;
									}
								}
								if(pans[pans.length-1][ebn[n]]==''){
									var ebmat=GetEdgeband(jsond,ebid);
									if(ebmat!=null){
										ebs.push(ebmat);
										pans[pans.length-1][ebn[n]]=ebs.length;
									}
								}
							}
						}
					}
				}
			}
			var left=true;
			for (var j = 0; j < pans.length; j++) {
				pNest=pans[j];
				
				inHTML +=('<tr class="groupcontent"><td><p></p></td>');
				
				inHTML +=('<td><p>' + pNest.t + '</p></td><td><p>' + pNest.w + '</p></td><td><p>' + pNest.l + '</p></td><td><p>' + pNest.qty + '</p></td></tr>');
				left=!left;
			}
			for (var j = pans.length; j < ebs.length; j++) {
				inHTML +=('<tr class="groupcontent"><td><p>('+ (j+1)  + ') ' + ebs[j].desc + '</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
			}
			inHTML +=('<tr class="grouplast"><td><p>&nbsp;</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td></tr></tr>');
		}
	}
	inHTML +=('</table>');
	inHTML +=('</div>');
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};


function WriteCost(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteCostingSummary();
	}
	else{
		loadScript(jsonsrc, function() {WriteCostingSummary();});
	}
};
//var WriteCostCB = function() {WriteCostingSummary();};
function WriteCostingSummary(){

	var jsond = JSON.parse(jsondata);
	jsond.cabs.pop();
	jsond.panels.pop();
	jsond.hardwares.pop();
	jsond.mat.pop();
	jsond.ebmat.pop();
	

	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	var subtotal=0;
	var total=0;
	
	
	for (var i = 0; i < jsond.cabs.length; i++) {
		var cab=jsond.cabs[i];
		cab.price=0;
		for (var j = 0; j < cab.panels.length; j++) {
			var cabpanel=cab.panels[j];
			var panel=GetPanel(jsond,cabpanel.name,cabpanel.conf);
			if(panel!=null){
				for (var k = 0; k < panel.ebs.length; k++) {
					var eb=panel.ebs[k];
					var ebmat=GetEdgeband(jsond,eb.id);
					if(ebmat!=null){
						cab.price+=cabpanel.qty*(eb.l/1000)*ebmat.ucost;
					}
				}
				var mat=GetMaterial(jsond,panel.mat);
				if(mat!=null){
					if(mat.costtype==0){
						cab.price+=cabpanel.qty*((panel.l/1000)*(panel.w/1000)*(mat.thickness/1000))*mat.ucost;
					}
					else if(mat.costtype==1){
						cab.price+=cabpanel.qty*((panel.l/1000)*(panel.w/1000))*mat.ucost;
					}
					else if(mat.costtype==2){
						cab.price+=cabpanel.qty*(panel.l/1000)*mat.ucost;
					}
				}
			}
		}
		
		for (var j = 0; j < cab.hardwares.length; j++) {
			var cabhard=cab.hardwares[j];
			var hard=GetHardware(jsond,cabhard.name,cabhard.conf,cabhard.swtype);
			if(hard!=null){
				cab.price+=cabhard.qty*hard.ucost;
			}
		}
	}
	
	for (var i = 0; i < jsond.ebmat.length; i++) {
		var ebmat=jsond.ebmat[i];
		ebmat.qty=0;
		for (var j = 0; j < jsond.panels.length; j++) {
			var panel=jsond.panels[j];
			for (var k = 0; k < jsond.panels[j].ebs.length; k++) {
				var eb=jsond.panels[j].ebs[k];
				if(eb.id==ebmat.id){
					ebmat.qty+=panel.qty*(eb.l/1000);
				}
			}
		}
	}
	
	for (var i = 0; i < jsond.mat.length; i++) {
		var mat=jsond.mat[i];
		mat.qty=0;
		mat.sunit=jsond.project.lengthunit+'<sup>3</sup>';
		if(mat.costtype==1){
			mat.sunit=jsond.project.lengthunit+'<sup>2</sup>';
		}
		else if(mat.costtype==2){
			mat.sunit=jsond.project.lengthunit;
		}
		for (var j = 0; j < jsond.panels.length; j++) {
			var panel=jsond.panels[j];
			if(panel.mat==mat.name){
				if(mat.costtype==0){
					mat.qty+=panel.qty*(panel.l/1000)*(panel.w/1000)*(mat.thickness/1000);
				}
				else if(mat.costtype==1){
					mat.qty+=panel.qty*(panel.l/1000)*(panel.w/1000);
				}
				else if(mat.costtype==2){
					mat.qty+=panel.qty*(panel.l/1000);
				}
			}
		}
	}
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Cost summary<p></div>');
	inHTML +=('<div class="separator"></div>');

	inHTML +=('<table class="content">');
	inHTML +=('<tr class="contentheader"><td><p>Order</p></td><td><p>Customer</p></td><td><p>Name</p></td><td><p>Qty</p></td><td><p>Width</p></td><td><p>Height</p></td><td><p>Depth</p></td><td><p>Price</p></td><td><p>Comment1</p></td><td><p>Comment2</p></td><td><p>Comment3</p></td></tr>');
	for (var i = 0; i < jsond.cabs.length; i++) {
		var cab=jsond.cabs[i];
		if(i<jsond.cabs.length-1){
			inHTML +=('<tr class="groupcontent">');
		}else
		{
			inHTML +=('<tr class="grouplast">');
		}

		inHTML +=('<td><p>' + jsond.project.order + '</p></td><td><p>' + jsond.project.cust + '</p></td><td><p>' + cab.name + '</p></td><td><p>' + cab.qty + '</p></td><td><p>' + cab.w + '</p></td><td><p>' + cab.h + '</p></td><td><p>' + cab.d + '</p></td><td><p>' + Number((cab.price*cab.qty).toFixed(2)) + '</p></td><td><p>' + cab.info1 + '</p></td><td><p>' + cab.info2 + '</p></td><td><p>' + cab.info3 + '</p></td>');
		inHTML +=('</tr>');
	}
	inHTML +=('</table>');
	
	inHTML +=('<div class="separator"></div>');
	
	subtotal=0;
	inHTML +=('<table class="content">');
	inHTML +=('<tr class="contentheader"><td><p>Material</p></td><td><p>Code</p></td><td><p>Qty</p></td><td><p>Unit</p></td><td><p>Unit price</p></td><td><p>Total price</p></td></tr>');
	for (var i = 0; i < jsond.mat.length; i++) {
		var mat=jsond.mat[i];
		inHTML +=('<tr class="groupcontent"><td><p>' + mat.name + '</p></td><td><p>' + mat.ref + '</p></td><td><p>' + Number((mat.qty*1000).toFixed(2)) + '</p></td><td><p>' + mat.sunit + '</p></td><td><p>' + mat.ucost + '</p></td><td class="costsubtotal"><p>' + Number(((mat.qty*mat.ucost)*1000).toFixed(2)) + '</p></td></tr>');
		subtotal+=((mat.qty*mat.ucost)*1000);
	}
	inHTML +=('<tr class="contenttotal"><td><p>Total</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td class="costtotal"><p>' + Number(subtotal.toFixed(2)) + '</p></td></tr>');
	inHTML +=('</table>');
	total+=subtotal;
	
	inHTML +=('<div class="separator"></div>');
	
	subtotal=0;
	inHTML +=('<table class="content">');
	inHTML +=('<tr class="contentheader"><td><p>Name</p></td><td><p>Description</p></td><td><p>Reference</p></td><td><p>Supplier</p></td><td><p>Qty</p></td><td><p>Unit price</p></td><td><p>Total price</p></td></tr>');
	for (var i = 0; i < jsond.hardwares.length; i++) {
		var hard=jsond.hardwares[i];
		inHTML +=('<tr class="groupcontent"><td><p>' + hard.name + '</p></td><td><p>' + hard.desc + '</p></td><td><p>' + hard.ref + '</p></td><td><p>' + hard.supplier + '</p></td><td><p>' + hard.qty + '</p></td><td><p>' + hard.ucost + '</p></td><td class="costsubtotal"><p>' + Number(((hard.qty*hard.ucost)*1000).toFixed(2)) + '</p></td></tr>');
		subtotal+=((hard.qty*hard.ucost)*1000);
	}
	inHTML +=('<tr class="contenttotal"><td><p>Total</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td><p></p></td><td class="costtotal"><p>' + Number(subtotal.toFixed(2)) + '</p></td></tr>');
	inHTML +=('</table>');
	total+=subtotal;
	
	inHTML +=('<div class="separator"></div>');
	
	subtotal=0;
	inHTML +=('<table class="content">');
	inHTML +=('<tr class="contentheader"><td><p>Edgebands</p></td><td><p>Code</p></td><td><p>Qty(in)</p></td><td><p>Unit price</p></td><td><p>Total price</p></td></tr>');
	for (var i = 0; i < jsond.ebmat.length; i++) {
		var ebmat=jsond.ebmat[i];
		inHTML +=('<tr class="groupcontent"><td><p>' + ebmat.name + '</p></td><td><p>' + ebmat.ref + '</p></td><td><p>' + Number((ebmat.qty*1000).toFixed(4)) + '</p></td><td><p>' + ebmat.ucost + '</p></td><td class="costsubtotal"><p>' + Number(((ebmat.qty*ebmat.ucost)*1000).toFixed(2)) + '</p></td></tr>');
		subtotal+=((ebmat.qty*ebmat.ucost)*1000);
	}
	inHTML +=('<tr class="contenttotal"><td><p>Total</p></td><td><p></p></td><td><p></p></td><td><p></p></td><td class="costtotal"><p>' + Number(subtotal.toFixed(2)) + '</p></td></tr>');
	inHTML +=('</table>');
	total+=subtotal;
	
	//inHTML +=('<div class="separator"></div>');
	//inHTML +=('<table class="content">');
	//inHTML +=('<tr class="contentheader"><td><p>Total</p></td><td><p>&nbsp;</p></td></tr>');
	//inHTML +=('<tr class="groupcontent"><td><p>?</p></td><td><p>?</p></td></tr>');
	//inHTML +=('<tr class="groupcontent"><td><p>?</p></td><td><p>?</p></td></tr>');
	//inHTML +=('<tr class="groupcontent"><td><p>?</p></td><td><p>?</p></td></tr>');
	//inHTML +=('<tr class="groupcontent"><td><p>?</p></td><td><p>?</p></td></tr>');
	//inHTML +=('<tr class="groupcontent"><td><p>?</p></td><td><p>?</p></td></tr>');
	//inHTML +=('<tr class="contenttotal"><td><p>Total</p></td><td class="costtotal"><p>' + Number(total.toFixed(2)) + '</p></td></tr>');
	//inHTML +=('</table>');
			
	inHTML +=('</div>');
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};


function WriteNestingProgramsList(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteNestProgList();
	}
	else{
		loadScript(jsonsrc, function() {WriteNestProgList();});
	}
};

function WriteNestProgList(){
	var jsond = JSON.parse(jsondata);
	jsond.nest.pop();
	
	var srcfilename = jsonsrc.substring(jsonsrc.lastIndexOf('/')+1);
	var docsdirectory = jsonsrc.substring(0,jsonsrc.lastIndexOf('/'));


	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Nesting sheets list<p></div>');
	inHTML +=('<div class="separator"></div>');
	
	inHTML +=('<table class="content" style="width:100%;"');
	
	var pNestQtyTot=0;
	
	for (var i = 0; i < jsond.nest.length; i++) {
		var pNest=jsond.nest[i];
		pNestQtyTot=Number(pNestQtyTot)+Number(pNest.qty);
	}
	
	inHTML +=('<tr>');
	inHTML +=('<td colspan="4" style="text-align:right;font-weight:bold;">Total Sheets: ' + Number(pNestQtyTot) + '</td>' );
	inHTML +=('</tr>');		
		
	inHTML +='</table>';
	
	inHTML +=('<table class="content" style="width:100%;"');
	
	for (var i = 0; i < jsond.nest.length; i++) {
		var pNest=jsond.nest[i];

		inHTML +=('<tr>');
		inHTML +=('<td rowspan="2" align="center">');
		inHTML +=('<a href="' + docsdirectory.substring(0,docsdirectory.lastIndexOf('/')) + "/Labels/Nesting/" + pNest.labels + '" style="text-decoration:none;float:right;"><img src="../../Ressources/labels.jpg" alt="labels" title="labels" width="30" height="30" onmouseover="this.src=\'../../Ressources/labelsOn.jpg\';" onmouseout="this.src=\'../../Ressources/labels.jpg\';" /></a>');
		inHTML +=('<a href="./ReportNestProg.html?progname=' + pNest.name + '&jsonsrc=%22' + jsonsrc + '%22">');
		inHTML +=('<img src="' + docsdirectory + "/IMAGE/" + pNest.img + '" width="750" height="450" border="0" />');
		inHTML +=('</a>');
		inHTML +=('</td>');
		inHTML +=('<td><p>Name: ' + pNest.name + '</p></td>' );
		inHTML +=('<td><p>Length: ' + pNest.l + '</p></td>' );
		inHTML +=('<td><p>Width: ' + pNest.w + '</p></td>' );
		inHTML +=('</tr>');
		
		inHTML +=('<tr>');
		inHTML +=('<td><p>Number: ' + pNest.id + '</p></td>' );
		inHTML +=('<td><p>Material: ' + pNest.mat + '</p></td>' );
		inHTML +=('<td><p>Quantity: ' + pNest.qty + '</p></td>' );
		inHTML +=('</tr>');
	}
	inHTML +='</table>';
	inHTML +='</div>';
	out.innerHTML=inHTML;
};

function WriteNestProgs(){
	GetParametersFromUrl();
	if(jsonsrc==undefined || jsonsrc.length==0){
		WriteNProgs();
	}
	else{
		loadScript(jsonsrc, function() {WriteNProgs();});
	}
};

function WriteNProgs(PFilter){
	var jsond = JSON.parse(jsondata);
	jsond.nest.pop();
	for (var i = 0; i < jsond.nest.length; i++) {
		jsond.nest[i].progparts.pop();
		jsond.nest[i].tools.pop();
		for (var j = 0; j < jsond.nest[i].tools.length;  j++) {
			jsond.nest[i].tools[j].spindles.pop();
		}
	}

	
	var srcfilename = jsonsrc.substring(jsonsrc.lastIndexOf('/')+1);
	var docsdirectory = jsonsrc.substring(0,jsonsrc.lastIndexOf('/'));


	var out = document.getElementById('output');
	var j=0;
	var inHTML='';
	for (var i = 0; i < jsond.nest.length; i++) {
		var pNest = jsond.nest[i];
		pNest.img=docsdirectory + "/IMAGE/" + pNest.img;
		pNest.labels=docsdirectory.substring(0,docsdirectory.lastIndexOf('/')) + "/Labels/Nesting/" + pNest.labels;
		if(PFilter==undefined || PFilter.length==0 || PFilter==pNest.name ){
			inHTML+=WriteNProg(jsond,pNest,inHTML);
			j=j+1;
		}
	}
	out.innerHTML=inHTML;
	
	out = document.getElementById('outputscript');
	out.innerHTML='';
};

function WriteNProg(jsond,pNest){
	var inHTML='';
	inHTML +=('<div class="page">');
	inHTML +=('<table class="content"><tr><td><p>Date: ' + jsond.project.date + '</p></td><td><p>Hour: ' + jsond.project.hour + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"><tr><td><p>Project: ' + jsond.project.name + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>Sheet number: ' + pNest.id + '<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content boldcontent"><tr><td><p>Name: ' + pNest.name + '</p></td><td><p>Qty: ' + pNest.qty + '</p></td></tr></table>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content boldcontent"><tr><td><p>Length: ' + pNest.l + jsond.project.lengthunit+'</p><p>Width: ' + pNest.w + jsond.project.lengthunit+'</p><p>Tickness: ' + pNest.t + jsond.project.lengthunit+'</p><p>Material: ' + pNest.mat + '</p></td><td><p>Order: ' + jsond.project.order + '</p><p>Customer: ' + jsond.project.cust + '</p><p>Program Time: ' + pNest.time + 's</p><td><p>Notes: ' + pNest.Tabs + '</p></td></tr></table>');//colonnes non identifiées <td><p>?1: 1</p><p>?2: 1</p><p>?3: 1</p></td>//
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="imgcontainer">');
	inHTML +=('<a href="' + pNest.labels + '" style="text-decoration:none;float:right;"><img src="../../Ressources/labels.jpg" alt="labels" title="labels" width="30" height="30" onmouseover="this.src=\'../../Ressources/labelsOn.jpg\';" onmouseout="this.src=\'../../Ressources/labels.jpg\';" /></a>');
	inHTML +=('<img src="' + pNest.img + '" alt="' + pNest.name + '" title="' + pNest.name + '" width="750" height="450" />');
	inHTML +=('</div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>PANEL List :<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"  style="width:100%;">');
	inHTML +=('<tr><td><p>#</p></td><td><p>Id</p></td><td><p>Part</p></td><td><p>Length</p></td><td><p>Width</p></td><td><p>Tickness</p></td><td><p>Front Edge</p></td><td><p>Back Edge</p></td><td><p>Left Edge</p></td><td><p>Right Edge</p></td><td><p>Notes</p></td></tr>');
	
	for (var i = 0; i < pNest.progparts.length; i++) {
		var pprogartdata=pNest.progparts[i];
		var ppanel=GetPanel(jsond,pprogartdata.name,pprogartdata.conf)
		if(ppanel!=null){
			inHTML +=('<tr><td><p><i>' + pprogartdata.id + '</i></p></td><td><p><i>' + pprogartdata.num + '</i></p></td><td><p>' + pprogartdata.name + '</p></td><td><p>' + ppanel.l + '</p></td><td><p>' + ppanel.w + '</p></td><td><p>' + ppanel.t + '</p></td><td><p>' + pprogartdata.ebf_c + '</p></td><td><p>' + pprogartdata.ebb_c + '</p></td><td><p>' + pprogartdata.ebr_c + '</p></td><td><p>' + pprogartdata.ebl_c + '</p></td><td><p>' + pprogartdata.ref + '</p></td></tr>');
		}
	}
	inHTML +=('</table>');
	
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<div class="titlecontainer"><p>TOOL List :<p></div>');
	inHTML +=('<div class="separator"></div>');
	inHTML +=('<table class="content"  style="width:100%;">');
	inHTML +=('<tr><td><p>Tool number</p></td><td><p>Diameter</p></td></tr>');
	
	for (var i = 0; i < pNest.tools.length; i++) {
		var ptooldata=pNest.tools[i];
		inHTML +=('<tr><td colspan="2" style="text-align:center;font-weight:bold;">' + ptooldata.name + '</td></tr>');
		if(ptooldata.name.indexOf("BP")==0){
		}
		else{
			inHTML +=('<tr><td style="width:50%;"><p><i>' + ptooldata.number + '</i></p></td><td><p><i>' + ptooldata.diameter + '</i></p></td></tr>');
		}
		for (var j = 0; j < ptooldata.spindles.length; j++) {
			var pspdldata=ptooldata.spindles[j];
			if(pspdldata.used!=0){
				inHTML +=('<tr><td style="width:50%;"><p><i>' + pspdldata.number + '</i></p></td><td><p><i>' + pspdldata.diameter + '</i></p></td></tr>');
			}
		}
	}
	inHTML +=('</table>');
	inHTML +=('</div>');
	
	return inHTML;
};

